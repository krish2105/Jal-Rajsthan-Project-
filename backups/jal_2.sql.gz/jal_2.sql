--
-- PostgreSQL database dump
--

\restrict QjTGAW2pb6BOKQqM9fDvQULpjtaOka2WeqcnijmoNKnNC3WhTUTVvxKFNEhqZsI

-- Dumped from database version 17.10 (Homebrew)
-- Dumped by pg_dump version 17.10 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: krishnamathurm4pro
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    ts timestamp with time zone DEFAULT now() NOT NULL,
    request_id text,
    actor text,
    role text,
    path text,
    status integer,
    latency_ms integer
);


ALTER TABLE public.audit_log OWNER TO krishnamathurm4pro;

--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: krishnamathurm4pro
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_log_id_seq OWNER TO krishnamathurm4pro;

--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: krishnamathurm4pro
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: works_ledger; Type: TABLE; Schema: public; Owner: krishnamathurm4pro
--

CREATE TABLE public.works_ledger (
    id bigint NOT NULL,
    block_uuid uuid NOT NULL,
    district text NOT NULL,
    structure text NOT NULL,
    sanctioned_n integer DEFAULT 0 NOT NULL,
    built_n integer DEFAULT 0 NOT NULL,
    verified_n integer DEFAULT 0 NOT NULL,
    scheme text,
    updated_by text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.works_ledger FORCE ROW LEVEL SECURITY;


ALTER TABLE public.works_ledger OWNER TO krishnamathurm4pro;

--
-- Name: works_ledger_id_seq; Type: SEQUENCE; Schema: public; Owner: krishnamathurm4pro
--

CREATE SEQUENCE public.works_ledger_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.works_ledger_id_seq OWNER TO krishnamathurm4pro;

--
-- Name: works_ledger_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: krishnamathurm4pro
--

ALTER SEQUENCE public.works_ledger_id_seq OWNED BY public.works_ledger.id;


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: krishnamathurm4pro
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: works_ledger id; Type: DEFAULT; Schema: public; Owner: krishnamathurm4pro
--

ALTER TABLE ONLY public.works_ledger ALTER COLUMN id SET DEFAULT nextval('public.works_ledger_id_seq'::regclass);


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: krishnamathurm4pro
--

COPY public.audit_log (id, ts, request_id, actor, role, path, status, latency_ms) FROM stdin;
1	2026-08-18 00:39:13.1708+04	77fc7ed5f906	api	-	/api/ledger	200	39
2	2026-08-18 00:39:13.185107+04	58257e6a504f	api	-	/api/ledger	200	8
3	2026-08-18 00:39:13.197383+04	34a11845639b	api	-	/api/ledger	200	7
4	2026-08-18 00:39:34.49634+04	4b926fd14f50	api	-	/api/health	200	84
\.


--
-- Data for Name: works_ledger; Type: TABLE DATA; Schema: public; Owner: krishnamathurm4pro
--

COPY public.works_ledger (id, block_uuid, district, structure, sanctioned_n, built_n, verified_n, scheme, updated_by, updated_at) FROM stdin;
1	029cfac5-3128-499a-8813-e18f8c9f1a5a	Jalor	percolation_tank	63	0	0	mgnrega	m4_plan	2026-08-18 00:38:31.995009+04
2	029cfac5-3128-499a-8813-e18f8c9f1a5a	Jalor	recharge_shaft	580	0	0	mgnrega	m4_plan	2026-08-18 00:38:31.996471+04
3	055ea5c9-8aa1-4769-89a7-08873809aeda	Jaipur	check_dam	33	0	0	mgnrega	m4_plan	2026-08-18 00:38:31.996838+04
4	055ea5c9-8aa1-4769-89a7-08873809aeda	Jaipur	percolation_tank	63	0	0	mgnrega	m4_plan	2026-08-18 00:38:31.997231+04
5	055ea5c9-8aa1-4769-89a7-08873809aeda	Jaipur	recharge_shaft	250	0	0	mgnrega	m4_plan	2026-08-18 00:38:31.997521+04
6	1679d838-7c15-4ee3-91eb-7ba14d31c9ab	Sikar	percolation_tank	90	0	0	mgnrega	m4_plan	2026-08-18 00:38:31.997989+04
7	1679d838-7c15-4ee3-91eb-7ba14d31c9ab	Sikar	recharge_shaft	361	0	0	mgnrega	m4_plan	2026-08-18 00:38:31.998398+04
8	1d60f7aa-aca3-4af8-b090-6b11c95aa93b	Jaisalmer	recharge_shaft	1000	0	0	mgnrega	m4_plan	2026-08-18 00:38:31.998666+04
9	21ef0a8d-3978-4154-b73f-fd43e78585b8	Barmer	percolation_tank	138	0	0	mgnrega	m4_plan	2026-08-18 00:38:31.998946+04
10	21ef0a8d-3978-4154-b73f-fd43e78585b8	Barmer	recharge_shaft	80	0	0	mgnrega	m4_plan	2026-08-18 00:38:31.999218+04
11	280c587b-35d5-4b10-9ec8-45a3d0b6b879	Jhunjhunu	check_dam	48	0	0	mgnrega	m4_plan	2026-08-18 00:38:31.999482+04
12	280c587b-35d5-4b10-9ec8-45a3d0b6b879	Jhunjhunu	percolation_tank	49	0	0	mgnrega	m4_plan	2026-08-18 00:38:31.999724+04
13	280c587b-35d5-4b10-9ec8-45a3d0b6b879	Jhunjhunu	recharge_shaft	193	0	0	mgnrega	m4_plan	2026-08-18 00:38:31.999974+04
14	327f0370-386f-4849-85fc-4ffb1870129a	Jaipur	percolation_tank	42	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.000217+04
15	327f0370-386f-4849-85fc-4ffb1870129a	Jaipur	recharge_shaft	169	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.000456+04
16	32c9a861-faaf-4337-97a1-8372c1b94ad4	Dausa	check_dam	17	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.000635+04
17	32c9a861-faaf-4337-97a1-8372c1b94ad4	Dausa	percolation_tank	78	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.000843+04
18	32c9a861-faaf-4337-97a1-8372c1b94ad4	Dausa	recharge_shaft	310	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.000983+04
19	33c7d5eb-8a83-40f4-8cdf-c074c345d5dd	Barmer	percolation_tank	57	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.001156+04
20	33c7d5eb-8a83-40f4-8cdf-c074c345d5dd	Barmer	recharge_shaft	620	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.001282+04
21	35eefa69-18fa-4ec2-bdf2-1d0a0c97b48e	Jhunjhunu	check_dam	33	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.001398+04
22	35eefa69-18fa-4ec2-bdf2-1d0a0c97b48e	Jhunjhunu	percolation_tank	63	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.001531+04
23	35eefa69-18fa-4ec2-bdf2-1d0a0c97b48e	Jhunjhunu	recharge_shaft	250	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.001658+04
24	3b7d09c5-ba0b-4863-8b9e-841296f2b647	Karauli	percolation_tank	57	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.001784+04
25	3b7d09c5-ba0b-4863-8b9e-841296f2b647	Karauli	recharge_shaft	230	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.001903+04
26	3ee243e4-898c-487b-8816-af11176545fe	Barmer	percolation_tank	51	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.002025+04
27	3ee243e4-898c-487b-8816-af11176545fe	Barmer	recharge_shaft	660	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.002149+04
28	403fa8dd-76b8-40b4-ab65-a667214b03a9	Sikar	percolation_tank	58	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.00228+04
29	403fa8dd-76b8-40b4-ab65-a667214b03a9	Sikar	recharge_shaft	234	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.002457+04
30	48e15084-a07e-4c36-ade5-1989f7747ec9	Alwar	percolation_tank	33	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.002646+04
31	48e15084-a07e-4c36-ade5-1989f7747ec9	Alwar	recharge_shaft	133	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.002842+04
32	4b0201cf-4fde-4cf0-ac2a-93fe495913cb	Jaipur	check_dam	11	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.003027+04
33	4b0201cf-4fde-4cf0-ac2a-93fe495913cb	Jaipur	percolation_tank	83	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.003219+04
34	4b0201cf-4fde-4cf0-ac2a-93fe495913cb	Jaipur	recharge_shaft	332	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.003406+04
35	4b0201cf-4fde-4cf0-ac2a-93fe495913cb	Jaipur	traditional_renovation	1	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.003597+04
36	50b25ae1-e9c3-4edb-8db2-6d542bdfb9d1	Churu	percolation_tank	18	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.003801+04
37	50b25ae1-e9c3-4edb-8db2-6d542bdfb9d1	Churu	recharge_shaft	880	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.00399+04
38	52d06f07-b575-4d77-9d9f-efe2eb9d49a3	Jalor	percolation_tank	91	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.004199+04
39	52d06f07-b575-4d77-9d9f-efe2eb9d49a3	Jalor	recharge_shaft	367	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.004407+04
40	5400d45d-019a-45eb-98e5-3754d3fd49cb	Barmer	recharge_shaft	1000	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.004563+04
41	5ca79fdd-4e50-4891-bd1f-017c6d948a7f	Jodhpur	percolation_tank	87	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.004717+04
42	5ca79fdd-4e50-4891-bd1f-017c6d948a7f	Jodhpur	recharge_shaft	420	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.004866+04
43	5de23b1e-82df-45fe-9b60-0d82b838f76b	Jaisalmer	recharge_shaft	1000	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.005016+04
44	6653a2e7-2ee6-4702-a7b2-4d7f921c7b8c	Sikar	percolation_tank	87	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.005384+04
45	6653a2e7-2ee6-4702-a7b2-4d7f921c7b8c	Sikar	recharge_shaft	420	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.005536+04
46	73bde824-95d3-41e0-b7f2-162b1c1bb4b1	Nagaur	percolation_tank	36	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.005708+04
47	73bde824-95d3-41e0-b7f2-162b1c1bb4b1	Nagaur	recharge_shaft	760	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.005909+04
48	7eed3b0d-5dcc-439f-99b2-e83175908ce8	Jaipur	check_dam	35	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.006088+04
49	7eed3b0d-5dcc-439f-99b2-e83175908ce8	Jaipur	percolation_tank	35	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.006246+04
50	7eed3b0d-5dcc-439f-99b2-e83175908ce8	Jaipur	recharge_shaft	141	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.006373+04
51	7eed3b0d-5dcc-439f-99b2-e83175908ce8	Jaipur	traditional_renovation	66	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.006501+04
52	8abd6676-84db-4292-8883-affc14fc9d4a	Jodhpur	percolation_tank	78	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.006633+04
53	8abd6676-84db-4292-8883-affc14fc9d4a	Jodhpur	recharge_shaft	480	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.006758+04
54	8b4d6b3c-d962-4766-90c7-062e032f8f84	Jodhpur	percolation_tank	75	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.006881+04
55	8b4d6b3c-d962-4766-90c7-062e032f8f84	Jodhpur	recharge_shaft	500	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.00702+04
56	8c41c21a-360c-4765-9934-91a4f059f6d1	Alwar	percolation_tank	33	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.007166+04
57	8c41c21a-360c-4765-9934-91a4f059f6d1	Alwar	recharge_shaft	132	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.007316+04
58	8c9800bb-6031-4bc3-8788-832bf6c94ba4	Nagaur	percolation_tank	60	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.007468+04
59	8c9800bb-6031-4bc3-8788-832bf6c94ba4	Nagaur	recharge_shaft	600	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.007616+04
60	8f21c9ba-b402-45b0-88b0-3a2b872e90cb	Jaipur	check_dam	34	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.007776+04
61	8f21c9ba-b402-45b0-88b0-3a2b872e90cb	Jaipur	percolation_tank	34	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.007928+04
62	8f21c9ba-b402-45b0-88b0-3a2b872e90cb	Jaipur	recharge_shaft	136	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.008082+04
63	8f21c9ba-b402-45b0-88b0-3a2b872e90cb	Jaipur	traditional_renovation	68	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.008224+04
64	90ab806c-2c4f-449c-b01d-c7e3cfbbef9c	Jodhpur	percolation_tank	84	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.008381+04
65	90ab806c-2c4f-449c-b01d-c7e3cfbbef9c	Jodhpur	recharge_shaft	440	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.008541+04
66	90efa33f-9a8e-4e16-85cc-84fa62b55165	Dausa	check_dam	44	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.008701+04
67	90efa33f-9a8e-4e16-85cc-84fa62b55165	Dausa	percolation_tank	44	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.008848+04
68	90efa33f-9a8e-4e16-85cc-84fa62b55165	Dausa	recharge_shaft	176	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.009048+04
69	90efa33f-9a8e-4e16-85cc-84fa62b55165	Dausa	traditional_renovation	21	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.009191+04
70	9bae7546-ae24-4bf8-9e8a-f69bb391292f	Jaipur	check_dam	23	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.009313+04
71	9bae7546-ae24-4bf8-9e8a-f69bb391292f	Jaipur	percolation_tank	72	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.00943+04
72	9bae7546-ae24-4bf8-9e8a-f69bb391292f	Jaipur	recharge_shaft	290	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.00984+04
73	a15fb699-15ee-47c8-bb14-0f4340aeae9d	Jodhpur	check_dam	7	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.009971+04
74	a15fb699-15ee-47c8-bb14-0f4340aeae9d	Jodhpur	percolation_tank	87	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.010086+04
75	a15fb699-15ee-47c8-bb14-0f4340aeae9d	Jodhpur	recharge_shaft	350	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.010196+04
76	a6a6408f-c8d2-4935-b68e-52a948ace974	Jodhpur	check_dam	8	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.010356+04
77	a6a6408f-c8d2-4935-b68e-52a948ace974	Jodhpur	percolation_tank	86	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.010507+04
78	a6a6408f-c8d2-4935-b68e-52a948ace974	Jodhpur	recharge_shaft	342	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.010712+04
79	a6a6408f-c8d2-4935-b68e-52a948ace974	Jodhpur	traditional_renovation	1	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.010885+04
80	a7b5756c-644a-4284-b6bc-09d68592bbe0	Dausa	percolation_tank	16	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.011036+04
81	a7b5756c-644a-4284-b6bc-09d68592bbe0	Dausa	recharge_shaft	64	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.011187+04
82	a9be1b04-13f8-46c0-94d1-98dff854bed9	Nagaur	check_dam	15	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.011335+04
83	a9be1b04-13f8-46c0-94d1-98dff854bed9	Nagaur	percolation_tank	79	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.011483+04
84	a9be1b04-13f8-46c0-94d1-98dff854bed9	Nagaur	recharge_shaft	318	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.011655+04
85	ad29791a-c754-4da8-b6b4-10f1e3b9b6d9	Jhunjhunu	percolation_tank	77	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.011811+04
86	ad29791a-c754-4da8-b6b4-10f1e3b9b6d9	Jhunjhunu	recharge_shaft	311	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.012015+04
87	af1f1e37-9dea-4377-a2e0-35645128e7f7	Bikaner	recharge_shaft	1000	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.012161+04
88	b06b3529-d5fe-4422-9c4b-33273720eaef	Alwar	check_dam	37	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.012295+04
89	b06b3529-d5fe-4422-9c4b-33273720eaef	Alwar	percolation_tank	59	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.012448+04
90	b06b3529-d5fe-4422-9c4b-33273720eaef	Alwar	recharge_shaft	236	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.012607+04
91	b6583c17-4ab9-4bd3-a581-f32f9f9690fb	Karauli	check_dam	45	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.012748+04
92	b6583c17-4ab9-4bd3-a581-f32f9f9690fb	Karauli	percolation_tank	45	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.012895+04
93	b6583c17-4ab9-4bd3-a581-f32f9f9690fb	Karauli	recharge_shaft	180	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.013031+04
94	b6583c17-4ab9-4bd3-a581-f32f9f9690fb	Karauli	traditional_renovation	16	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.013166+04
95	b951a7f6-7753-462c-aeb1-2edd57c91b63	Jodhpur	percolation_tank	93	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.0133+04
96	b951a7f6-7753-462c-aeb1-2edd57c91b63	Jodhpur	recharge_shaft	380	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.013663+04
97	be984c0f-695b-4324-a44d-db7a46085255	Jaipur	check_dam	38	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.013814+04
98	be984c0f-695b-4324-a44d-db7a46085255	Jaipur	percolation_tank	38	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.013972+04
99	be984c0f-695b-4324-a44d-db7a46085255	Jaipur	recharge_shaft	150	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.014224+04
100	be984c0f-695b-4324-a44d-db7a46085255	Jaipur	traditional_renovation	52	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.014411+04
101	c144281a-7dd9-42ee-9125-9ec5d70c7f0f	Jhunjhunu	check_dam	21	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.014606+04
102	c144281a-7dd9-42ee-9125-9ec5d70c7f0f	Jhunjhunu	percolation_tank	74	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.014803+04
103	c144281a-7dd9-42ee-9125-9ec5d70c7f0f	Jhunjhunu	recharge_shaft	296	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.014935+04
104	c7ef9d8f-4a0a-455e-915a-4a9e000bc37c	Jaisalmer	recharge_shaft	1000	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.015068+04
105	c87dcbb1-29c0-42f9-939b-d7b920560aa5	Jaipur	check_dam	32	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.015201+04
106	c87dcbb1-29c0-42f9-939b-d7b920560aa5	Jaipur	percolation_tank	63	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.01534+04
107	c87dcbb1-29c0-42f9-939b-d7b920560aa5	Jaipur	recharge_shaft	255	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.015471+04
108	c87dcbb1-29c0-42f9-939b-d7b920560aa5	Jaipur	traditional_renovation	1	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.015601+04
109	ca4b2cf3-0fe4-4c6a-8163-05c1dca5cf5c	Jodhpur	percolation_tank	39	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.015728+04
110	ca4b2cf3-0fe4-4c6a-8163-05c1dca5cf5c	Jodhpur	recharge_shaft	740	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.015861+04
111	d00a9db3-9140-4b24-b1b1-6257b062ed75	Jaipur	percolation_tank	51	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.016003+04
112	d00a9db3-9140-4b24-b1b1-6257b062ed75	Jaipur	recharge_shaft	207	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.016167+04
113	d1905650-088e-4944-a44b-5117b0a22860	Jodhpur	percolation_tank	78	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.016285+04
114	d1905650-088e-4944-a44b-5117b0a22860	Jodhpur	recharge_shaft	480	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.016446+04
115	d3df8a19-d5a2-4a8b-a5f7-ab26592a6fdd	Dausa	check_dam	44	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.016603+04
116	d3df8a19-d5a2-4a8b-a5f7-ab26592a6fdd	Dausa	percolation_tank	52	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.016747+04
117	d3df8a19-d5a2-4a8b-a5f7-ab26592a6fdd	Dausa	recharge_shaft	211	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.016896+04
118	d4828392-a2b6-436b-beab-33915aa45bf7	Bikaner	percolation_tank	64	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.017025+04
119	d4828392-a2b6-436b-beab-33915aa45bf7	Bikaner	recharge_shaft	16	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.0172+04
120	d612b810-3bef-4b99-b506-6adc3d462ad7	Jhunjhunu	percolation_tank	71	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.017327+04
121	d612b810-3bef-4b99-b506-6adc3d462ad7	Jhunjhunu	recharge_shaft	286	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.017464+04
122	d9711b2e-af1c-408f-9b05-4aaf2ff047f5	Jaipur	check_dam	39	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.01765+04
123	d9711b2e-af1c-408f-9b05-4aaf2ff047f5	Jaipur	percolation_tank	39	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.017785+04
124	d9711b2e-af1c-408f-9b05-4aaf2ff047f5	Jaipur	recharge_shaft	157	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.017917+04
125	d9711b2e-af1c-408f-9b05-4aaf2ff047f5	Jaipur	traditional_renovation	46	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.018045+04
126	ebfbdd3c-c79e-4161-8f6f-7621920ded18	Jaipur	percolation_tank	41	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.018186+04
127	ebfbdd3c-c79e-4161-8f6f-7621920ded18	Jaipur	recharge_shaft	167	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.018303+04
128	ece5b933-909f-4439-91d2-74d217d4ea94	Nagaur	percolation_tank	60	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.018428+04
129	ece5b933-909f-4439-91d2-74d217d4ea94	Nagaur	recharge_shaft	600	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.018554+04
130	f52d6317-a1f5-416f-88da-ba16e1cd1078	Barmer	percolation_tank	57	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.018692+04
131	f52d6317-a1f5-416f-88da-ba16e1cd1078	Barmer	recharge_shaft	620	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.018817+04
132	f8a9f2cf-caa2-4ec5-ad49-83be51271798	Jodhpur	percolation_tank	75	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.018936+04
133	f8a9f2cf-caa2-4ec5-ad49-83be51271798	Jodhpur	recharge_shaft	500	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.019055+04
134	f8cbc747-f79c-4e82-818e-bde152b6d905	Jaipur	percolation_tank	30	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.01918+04
135	f8cbc747-f79c-4e82-818e-bde152b6d905	Jaipur	recharge_shaft	120	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.019316+04
136	fbebc4bd-8085-444f-9e93-02ea11dca7e5	Jaisalmer	check_dam	6	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.01945+04
137	fbebc4bd-8085-444f-9e93-02ea11dca7e5	Jaisalmer	injection_well	12	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.019574+04
138	fbebc4bd-8085-444f-9e93-02ea11dca7e5	Jaisalmer	percolation_tank	6	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.019703+04
139	fbebc4bd-8085-444f-9e93-02ea11dca7e5	Jaisalmer	recharge_shaft	25	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.019825+04
140	fbebc4bd-8085-444f-9e93-02ea11dca7e5	Jaisalmer	traditional_renovation	12	0	0	mgnrega	m4_plan	2026-08-18 00:38:32.019951+04
\.


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: krishnamathurm4pro
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 4, true);


--
-- Name: works_ledger_id_seq; Type: SEQUENCE SET; Schema: public; Owner: krishnamathurm4pro
--

SELECT pg_catalog.setval('public.works_ledger_id_seq', 140, true);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: krishnamathurm4pro
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: works_ledger works_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: krishnamathurm4pro
--

ALTER TABLE ONLY public.works_ledger
    ADD CONSTRAINT works_ledger_pkey PRIMARY KEY (id);


--
-- Name: idx_audit_ts; Type: INDEX; Schema: public; Owner: krishnamathurm4pro
--

CREATE INDEX idx_audit_ts ON public.audit_log USING btree (ts DESC);


--
-- Name: idx_ledger_district; Type: INDEX; Schema: public; Owner: krishnamathurm4pro
--

CREATE INDEX idx_ledger_district ON public.works_ledger USING btree (district);


--
-- Name: works_ledger works_district_scope; Type: POLICY; Schema: public; Owner: krishnamathurm4pro
--

CREATE POLICY works_district_scope ON public.works_ledger USING (((current_setting('app.role'::text, true) = 'district_officer'::text) AND (district = current_setting('app.district'::text, true))));


--
-- Name: works_ledger; Type: ROW SECURITY; Schema: public; Owner: krishnamathurm4pro
--

ALTER TABLE public.works_ledger ENABLE ROW LEVEL SECURITY;

--
-- Name: works_ledger works_secretary_all; Type: POLICY; Schema: public; Owner: krishnamathurm4pro
--

CREATE POLICY works_secretary_all ON public.works_ledger USING ((current_setting('app.role'::text, true) = ANY (ARRAY['secretary'::text, 'analyst'::text])));


--
-- Name: TABLE audit_log; Type: ACL; Schema: public; Owner: krishnamathurm4pro
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.audit_log TO jal_app;


--
-- Name: SEQUENCE audit_log_id_seq; Type: ACL; Schema: public; Owner: krishnamathurm4pro
--

GRANT SELECT,USAGE ON SEQUENCE public.audit_log_id_seq TO jal_app;


--
-- Name: TABLE works_ledger; Type: ACL; Schema: public; Owner: krishnamathurm4pro
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.works_ledger TO jal_app;


--
-- Name: SEQUENCE works_ledger_id_seq; Type: ACL; Schema: public; Owner: krishnamathurm4pro
--

GRANT SELECT,USAGE ON SEQUENCE public.works_ledger_id_seq TO jal_app;


--
-- PostgreSQL database dump complete
--

\unrestrict QjTGAW2pb6BOKQqM9fDvQULpjtaOka2WeqcnijmoNKnNC3WhTUTVvxKFNEhqZsI

